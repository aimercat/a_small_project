package User_Interface_layer;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.AbstractListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Business_Logic_Layer.Book;
import Business_Logic_Layer.Rent;
import Business_Logic_Layer.YXZP;
import Data_access_layer.RentTable;
import Data_access_layer.YXZPTable;

import java.awt.Font;
import javax.swing.JTextField;

public class ReturnGUI {

	public JFrame frame;
	public static int rid;
	public static int id;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReturnGUI window = new ReturnGUI(0, 0);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ReturnGUI(int r_id,int _id) {
		rid=r_id;
		id=_id;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(200, 200, 500, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("\u60A8\u786E\u5B9A\u8981\u5F52\u8FD8\u8BE5\u97F3\u50CF\u5236\u54C1\u5417\uFF1F");
		label.setFont(new Font("����", Font.BOLD | Font.ITALIC, 20));
		label.setBounds(78, 100, 282, 67);
		frame.getContentPane().add(label);
		
		JButton button = new JButton("\u53D6\u6D88");
		button.setToolTipText("�˳���ǰҳ�棬�벻Ҫ�����Ϸ��ġ�");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		button.setBounds(261, 197, 113, 27);
		frame.getContentPane().add(button);
		
		JButton button_OK = new JButton("\u786E\u8BA4\u5F52\u8FD8");//ȷ��
		button_OK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Rent r1 = new Rent();
					r1.update_falg(rid);
					YXZP y1=new YXZP();
					y1.ChangeStatus0(id);
					Return_success succ=new Return_success();
					succ.frame.setVisible(true);
					Book b1=new Book();
					b1.Change_astatus2(rid);
					frame.dispose();
					
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    
				
			}
		});
		button_OK.setBounds(78, 197, 113, 27);
		frame.getContentPane().add(button_OK);
	}
}
