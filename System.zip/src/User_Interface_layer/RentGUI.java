package User_Interface_layer;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JToggleButton;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.AbstractListModel;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import Business_Logic_Layer.Book;
import Business_Logic_Layer.Rent;
import Business_Logic_Layer.User;
import Business_Logic_Layer.YXZP;
import Data_access_layer.RentTable;
import Data_access_layer.UserTable;
import Data_access_layer.YXZPTable;
import javax.swing.JSpinner;
import javax.swing.event.AncestorListener;
import javax.swing.event.AncestorEvent;
import javax.swing.JSlider;

public class RentGUI {

	public JFrame frame;
	private JTextField textField_name;
	private JButton button_select;
	private JLabel label_1;
	private JTextField textField_yname;
	private JLabel label_2;
	private JTable table;
	private JTextField textField_country;
	private JTable table_1;
    public  static  String dateString;
    public  static int  days;
    public  static int  usr_id;
    public static String u_name;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RentGUI window = new RentGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RentGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
	
		frame = new JFrame();
		frame.setBounds(200, 200, 800, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
	    int min = 1;     //����С��1
	    int max = 15;   //����15��
	    int step = 1;
	    int initValue = 1;  //��ʼΪ1
	    SpinnerModel model = new SpinnerNumberModel(initValue, min, max, step);
	    JSpinner spinner = new JSpinner(model);
		spinner.setToolTipText("���ʱ��15��");
		spinner.setBounds(281, 365, 47, 24);
		frame.getContentPane().add(spinner);
		
		
		JLabel label = new JLabel("\u6B22\u8FCE\u60A8\uFF0C\u7528\u6237:");
		label.setBounds(25, 16, 100, 18);
		frame.getContentPane().add(label);
		JLabel label_name = new JLabel(GUI.uname);
		
	
		
		label_name.setBounds(106, 13, 86, 24);
		frame.getContentPane().add(label_name);
		
		
		
		
		
		label_1 = new JLabel("\u5F71\u7247\u540D\u79F0\uFF1A");
		label_1.setBounds(106, 56, 86, 18);
		frame.getContentPane().add(label_1);
		
		textField_yname = new JTextField();
		textField_yname.setBounds(177, 53, 86, 24);
		frame.getContentPane().add(textField_yname);
		textField_yname.setColumns(10);
		
		label_2 = new JLabel("\u5F71\u789F\u7C7B\u578B\uFF1A");
		label_2.setBounds(442, 56, 72, 18);
		frame.getContentPane().add(label_2);
		
		JComboBox comboBox_type = new JComboBox();
		comboBox_type.setModel(new DefaultComboBoxModel(new String[] {"\u4E0D\u9650", "DVD12", "VSH5", "VSH8", "VSH10"}));
		comboBox_type.setBounds(503, 53, 54, 24);
		frame.getContentPane().add(comboBox_type);
		
		JLabel lblNewLabel = new JLabel("\u88AB\u79DF\u8D70\u4E86\uFF1F\u8BD5\u8BD5\u9884\u8BA2\u5427");
		lblNewLabel.setBounds(-13, 434, 152, 18);
		frame.getContentPane().add(lblNewLabel);
		
		JComboBox comboBox_type2 = new JComboBox();
		comboBox_type2.setModel(new DefaultComboBoxModel(new String[] {"\u5168\u90E8", "\u672A\u501F\u51FA", "\u53EF\u9884\u8BA2"}));
		comboBox_type2.setBounds(649, 53, 81, 24);
		frame.getContentPane().add(comboBox_type2);
		
		JLabel label_3 = new JLabel("\u8303\u56F4\uFF1A");
		label_3.setBounds(603, 56, 72, 18);
		frame.getContentPane().add(label_3);
		
		JButton button_book = new JButton("\u9884\u8BA2");   //Ԥ��
		button_book.setToolTipText("�뽫��Χ����Ϊ��Ԥ������ѯˢ��");
		button_book.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox_type2.getSelectedIndex()==2) {
					int index=table.getSelectedRow();
					int id=(int) YXZPTable.Data[index][0];
					int rid = 0;
					int uid = 0;
					try {
					RentTable r1=new RentTable();
					r1.Select_id(id);
					while(r1.resultSet.next())
					{
						if(r1.resultSet.getInt("flag")==1)
							rid=r1.resultSet.getInt("rid");
					}
					
					User usr=new User();
					u_name=GUI.uname;
					while(UserTable.resultSet.next()) {
						if(UserTable.resultSet.getString("uname").equals(u_name))
						uid=UserTable.resultSet.getInt("uid");
						
								
					}
					}catch(Exception e1) {
						e1.printStackTrace();
					}
					BookGUI b1=new BookGUI(id,uid,rid);
					b1.frame.setVisible(true);
					
				}
			}
		});
		button_book.setBounds(47, 454, 113, 27);
		frame.getContentPane().add(button_book);
		
		JLabel label_4 = new JLabel("\u7528\u6237\u5DF2\u79DF\u501F");
		label_4.setBounds(658, 351, 72, 18);
		frame.getContentPane().add(label_4);
		
		JButton button_return = new JButton("\u6211\u8981\u5F52\u8FD8"); //�黹
		button_return.setText("\u786E\u8BA4\u5F52\u8FD8");
		button_return.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int index=table_1.getSelectedRow();
				int rid=(int) RentTable.Data[index][0];
				int id=(int) RentTable.Data[index][1];
				try {
					
					ReturnGUI  window=new ReturnGUI(rid,id);
				
				window.frame.setVisible(true);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			}
		});
		button_return.setBounds(425, 526, 113, 27);
		frame.getContentPane().add(button_return);
		
		JButton button_rent = new JButton("\u79DF\u501F\u786E\u8BA4");  //���
		button_rent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int index=table.getSelectedRow();
				int id=(int) YXZPTable.Data[index][0];
				days=(int) spinner.getValue();
				YXZP  yx=new YXZP();
				int status=0;
				try {
					YXZPTable.Select(YXZPTable.SelectYX);
					while(YXZPTable.resultSet.next()) {
						if(YXZPTable.resultSet.getInt("id")==id) {
							 status=YXZPTable.resultSet.getInt("rstatus");
						}
					}
					YXZPTable.resultSet.beforeFirst();
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
				if(RentTable.row>=6) {
					RentBad b1=new RentBad();
					b1.frame.setVisible(true);
					
				}
				else if(status!=0) {
					
				}
				else if(status==0) {
				RentConfirm window;
				try {
					window = new RentConfirm(id,days);
					window.frame.setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				}
			}
		});
		button_rent.setBounds(47, 364, 113, 27);
		frame.getContentPane().add(button_rent);
		
		JButton button_exit = new JButton("ע�����ص�¼ҳ��");
		button_exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI   l=new GUI();
                frame.dispose();
			}
		});
		button_exit.setBounds(669, 0, 113, 27);
		frame.getContentPane().add(button_exit);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(48, 79, 734, 272);
		frame.getContentPane().add(scrollPane);
		String[] head=new String[] {
				"id", "\u5236\u54C1\u7C7B\u578B", "\u540D\u79F0", "\u5BFC\u6F14", "\u4E3B\u6F14", "\u56FD\u5BB6", "\u4E0A\u6620\u65E5\u671F", "\u5907\u6CE8\u4FE1\u606F", "\u72B6\u6001"
			
				
		};
		String[] head2=new String[] {
				"����","id","״̬"
		};
		table = new JTable();   //��1   ���  ��ʾ��ѯ������Ʒ�Ľṹ
		table.setModel(new DefaultTableModel(
			null,head));
		table_1 = new JTable();  //��2  С��
		table_1.setModel(new DefaultTableModel(
			null,
			head2
		));
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(552, 370, 230, 183);
		frame.getContentPane().add(scrollPane_1);
		scrollPane_1.setViewportView(table_1);  //z
		button_select = new JButton("\u67E5\u8BE2");    //��ѯ
		button_select.setMnemonic(KeyEvent.VK_ENTER);
		button_select.setToolTipText("ÿ�β�����������ѯˢ��ҳ��");
		button_select.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {int x=comboBox_type2.getSelectedIndex();
				     int y=comboBox_type.getSelectedIndex();
					
					String country=textField_country.getText();
					String name=textField_yname.getText();
					
					YXZP   yinx=new YXZP();
					yinx.setcountry(country);
					yinx.setname(name);
					yinx.SQL(x, y);
					yinx.Select();
					table.setModel(new DefaultTableModel(YXZPTable.queryData(),head));
					User u1=new User();
					u1.Is_name(GUI.uname);
					int zid=u1.u_id;
					
					RentTable rent=new RentTable();
					
					rent.Select_uid(zid);
					table_1.setModel(new DefaultTableModel(rent.queryData(),head2));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		button_select.setBounds(0, 47, 81, 27);
		frame.getContentPane().add(button_select);
		scrollPane.setViewportView(table);
		
		JLabel label_5 = new JLabel("\u56FD\u5BB6\uFF1A");
		label_5.setBounds(268, 56, 72, 18);
		frame.getContentPane().add(label_5);
		
		textField_country = new JTextField();
		textField_country.setBounds(317, 53, 86, 24);
		frame.getContentPane().add(textField_country);
		textField_country.setColumns(10);
	
		
		
		
		JLabel lblNewLabel_1 = new JLabel("\u4ECA\u5929\u662F\uFF1A");
		lblNewLabel_1.setBounds(242, 16, 72, 18);
		frame.getContentPane().add(lblNewLabel_1);
		Date date = new Date();
	    long times = date.getTime();//ʱ���
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	    dateString = formatter.format(date);
		JLabel timeLabel = new JLabel(dateString);
		timeLabel.setBounds(293, 16, 72, 18);
		frame.getContentPane().add(timeLabel);
		
		
		JLabel lblNewLabel_2 = new JLabel("\u79DF\u501F\u5929\u6570\uFF1A");
		lblNewLabel_2.setBounds(227, 368, 72, 18);
		frame.getContentPane().add(lblNewLabel_2);

			    
			    
	}
}
