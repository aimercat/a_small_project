package User_Interface_layer;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Data_access_layer.BookTable;
import Data_access_layer.UserTable;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class RootGUI {

	public JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RootGUI window = new RootGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RootGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(400, 200, 600,500 );
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblroot = new JLabel("\u7BA1\u7406\u5458\uFF1Aroot");
		lblroot.setFont(new Font("����", Font.BOLD | Font.ITALIC, 18));
		lblroot.setBounds(14, 13, 132, 34);
		frame.getContentPane().add(lblroot);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(132, 94, 436, 257);
		frame.getContentPane().add(scrollPane);
		String[] head=new String[] {
				"aid", "uid", "id", "\u72B6\u6001"
			};
		table = new JTable();
		table.setModel(new DefaultTableModel(
			null,
			head
			
		));
		scrollPane.setViewportView(table);
		String[] head2=new String[] {
				"uid","���","�û���","����","��ַ","����","�绰"
		};
		JLabel lblNewLabel = new JLabel("\u5F53\u524D\u9884\u8BA2\u8868\u4E2D\u53EF\u4EE5\u63D0\u9192\u79DF\u501F\u7684\u7528\u6237\u5982\u4E0B\uFF1A");
		lblNewLabel.setBounds(132, 45, 276, 38);
		frame.getContentPane().add(lblNewLabel);
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"\u63D0\u9192", "\u67E5\u8BE2\u7528\u6237 \u4FE1\u606F\u8868"}));
		comboBox.setBounds(164, 20, 73, 24);
		frame.getContentPane().add(comboBox);
		JButton button = new JButton("\u5237\u65B0");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BookTable b2;
				if(comboBox.getSelectedIndex()==0) {
				try {
					b2 = new BookTable();
					b2.root_select();
					table.setModel(new DefaultTableModel(BookTable.queryData(),head));
					
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				}
				if(comboBox.getSelectedIndex()==1) {
					UserTable b3;
					try {
						b3 = new  UserTable();
						b3.Select();
						table.setModel(new DefaultTableModel(UserTable.queryData(),head2));
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					}
			}
		});
		button.setBounds(14, 98, 113, 27);
		frame.getContentPane().add(button);
		
		JButton button_1 = new JButton("\u9000\u51FA\u7CFB\u7EDF");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(-1);
			}
		});
		button_1.setBounds(14, 392, 113, 27);
		frame.getContentPane().add(button_1);
		
		
	}
}
