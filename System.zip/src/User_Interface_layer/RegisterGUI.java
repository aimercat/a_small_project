package User_Interface_layer;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Business_Logic_Layer.User;
import Data_access_layer.UserTable;

import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Color;

public class RegisterGUI {

	JFrame frame;
	private JTextField textField_name;
	private JPasswordField passwordField;
	private JTextField textField_pnumber;
	private JTextField textField_email;
	private JTextField textField_address;
	private JTextField textField_password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegisterGUI window = new RegisterGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RegisterGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(245, 255, 250));
		frame.getContentPane().setFont(new Font("����", Font.PLAIN, 15));
		frame.setBounds(100, 100, 500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label_name = new JLabel("\u7528\u6237\u540D\uFF1A");
		label_name.setFont(new Font("����", Font.PLAIN, 15));
		label_name.setBounds(47, 59, 72, 18);
		frame.getContentPane().add(label_name);
		
		JLabel label = new JLabel("\u786E\u8BA4\u5BC6\u7801\uFF1A");
		label.setFont(new Font("����", Font.PLAIN, 15));
		label.setBounds(47, 129, 88, 18);
		frame.getContentPane().add(label);
		
		textField_name = new JTextField();
		textField_name.setBounds(136, 56, 125, 24);
		frame.getContentPane().add(textField_name);
		textField_name.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(136, 123, 125, 24);
		frame.getContentPane().add(passwordField);
		
		JLabel label_pnumber = new JLabel("\u7535\u8BDD\uFF1A");
		label_pnumber.setFont(new Font("����", Font.PLAIN, 15));
		label_pnumber.setBounds(47, 160, 72, 18);
		frame.getContentPane().add(label_pnumber);
		
		textField_pnumber = new JTextField();
		textField_pnumber.setBounds(136, 154, 125, 24);
		frame.getContentPane().add(textField_pnumber);
		textField_pnumber.setColumns(10);
		
		JLabel label_email = new JLabel("\u90AE\u7BB1\uFF1A");
		label_email.setFont(new Font("����", Font.PLAIN, 15));
		label_email.setBounds(47, 197, 72, 18);
		frame.getContentPane().add(label_email);
		
		JLabel label_1 = new JLabel("\u5730\u5740\uFF1A");
		label_1.setFont(new Font("����", Font.PLAIN, 15));
		label_1.setBounds(47, 234, 72, 18);
		frame.getContentPane().add(label_1);
		
		textField_email = new JTextField();
		textField_email.setBounds(136, 191, 125, 24);
		frame.getContentPane().add(textField_email);
		textField_email.setColumns(10);
		
		textField_address = new JTextField();
		textField_address.setBounds(136, 228, 125, 24);
		frame.getContentPane().add(textField_address);
		textField_address.setColumns(10);
		
		JLabel label_2 = new JLabel("\uFF08\u9009\u586B\uFF09");
		label_2.setBounds(279, 194, 72, 18);
		frame.getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("\uFF08\u9009\u586B\uFF09");
		label_3.setBounds(279, 234, 72, 18);
		frame.getContentPane().add(label_3);
		
		JButton button_confirm = new JButton("\u6CE8\u518C");
		button_confirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String uname=textField_name.getText();
				@SuppressWarnings("deprecation")
				String upassword=passwordField.getText();
				String uemail=textField_email.getText();
				String uaddress=textField_address.getText();
				String phone=textField_pnumber.getText();
				String password1=textField_password.getText();
				try {
					User user=new User();
					if(uname.equals("")||upassword.equals("")||phone.equals("")){
						  NULL  window=new NULL();
						  window.frame.setVisible(true);
					}     
						else if(user.Is_name(uname)) {
						NameBad  window=new NameBad();
						window.frame.setVisible(true);
						}
						else if(!password1.equals(upassword)) {
							PasswordBad window=new PasswordBad();
							window.frame.setVisible(true);
						}
						else {
							user.SetUsr(uname,password1,uaddress,uemail,phone);//����ֵ
							user.Register_insert();                           //�������ݿ�
							
							Register_success  window=new Register_success();  //ע��ɹ�
							window.frame.setVisible(true);
							UserTable.JDBCclose();   //�ر�����
							
						}
							
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		button_confirm.setBounds(47, 278, 113, 27);
		frame.getContentPane().add(button_confirm);
		
		JButton button_exit = new JButton("\u9000\u51FA");
		button_exit.setBounds(279, 278, 113, 27);
		frame.getContentPane().add(button_exit);
		
		JLabel label_4 = new JLabel("\u5BC6\u7801\uFF1A");
		label_4.setFont(new Font("����", Font.PLAIN, 15));
		label_4.setBounds(47, 90, 72, 18);
		frame.getContentPane().add(label_4);
		
		textField_password = new JTextField();
		textField_password.setBounds(136, 87, 125, 24);
		frame.getContentPane().add(textField_password);
		textField_password.setColumns(10);
		button_exit.addActionListener(new ActionListener() {
	        
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            // TODO �Զ����ɵķ������
	            if(e.getActionCommand().equals("�˳�")){
	            	frame.dispose();          //���رյ�ǰ����
	            }
	        }
	    });
	}
}
