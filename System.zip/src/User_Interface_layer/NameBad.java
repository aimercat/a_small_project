package User_Interface_layer;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NameBad {

	protected JFrame frame;

	/**
	 * Launch the application.
	 */


	/**
	 * Create the application.
	 */
	 

	public NameBad() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("\u8BE5\u7528\u6237\u540D\u5DF2\u7ECF\u5B58\u5728\uFF01");
		label.setFont(new Font("����", Font.BOLD, 20));
		label.setBounds(107, 83, 189, 84);
		frame.getContentPane().add(label);
		
		JButton button = new JButton("\u786E\u8BA4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		button.setBounds(134, 157, 113, 27);
		frame.getContentPane().add(button);
	}
}
