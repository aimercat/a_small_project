package User_Interface_layer;


import java.awt.Container;
import java.awt.Font;
import java.awt.Label;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.CaretListener;

import Business_Logic_Layer.User;
import Data_access_layer.UserTable;

import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
public class GUI extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField textField;
	private JPasswordField passwordField;
	private final Action action = new SwingAction();
	public static  String uname=null;
	protected static  int balance;
     public GUI() {
    setBak(); //���ñ�������
    Container c = getContentPane(); //��ȡJFrame���
    JPanel jp = new JPanel(); //������JPanel
    jp.setOpaque(false); //��JPanel����Ϊ͸�� �����Ͳ�����ס����ı��� �����������JPanel����������
    c.add(jp);
    jp.setLayout(null);
    Font f1 = new Font("Serief",Font.BOLD,16);
    
    JLabel Label_userid = new JLabel("\u7528\u6237\u540D\uFF1A");
    Label_userid.setFont(new Font("΢���ź� Light", Font.BOLD | Font.ITALIC, 16));
    Label_userid.setBounds(112, 185, 68, 36);
    jp.add(Label_userid);
    
    textField = new JTextField(15);   //name�ı���
    textField.setBounds(181, 192, 99, 24);
    textField.setToolTipText("�������û������������ظ����Ƽ�Ϊ��ĸ������϶���");
    jp.add(textField);
    textField.setColumns(10);
    
    JLabel Label_password = new JLabel("\u5BC6\u7801\uFF1A");  
    Label_password.setFont(new Font("΢���ź� Light", Font.BOLD | Font.ITALIC, 16));
    Label_password.setBounds(112, 234, 72, 18);
    jp.add(Label_password);
    
    passwordField = new JPasswordField(15);
    passwordField.setBounds(181, 231, 99, 24);
    jp.add(passwordField);
    
    JComboBox comboBox = new JComboBox();   //ѡ������
    comboBox.setModel(new DefaultComboBoxModel(new String[] {"\u8EAB\u4EFD\uFF1A\u7528\u6237", "\u8EAB\u4EFD\uFF1A\u7BA1\u7406\u5458"}));
    comboBox.setToolTipText("����Ա�˻�����ע�ᣬ��ӿ�����Ա����ȡ");
    comboBox.setBounds(340, 0, 128, 24);
    jp.add(comboBox);
    JButton button_Login = new JButton("\u767B\u5F55");      //��¼
    button_Login.addActionListener(new ActionListener() {
    	@SuppressWarnings("deprecation")
		public void actionPerformed(ActionEvent e) {
    		   uname=textField.getText();
    	    
			String   upasssword=passwordField.getText();
    		User  user=new User();
    		if(comboBox.getSelectedIndex()==0) {
				try {
					user.Login(uname, upasssword);
					balance=user.getmoney();
					dispose();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				}
    		if(comboBox.getSelectedIndex()==1) {
    			try {
					if(user.Login(uname, upasssword)) {
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
    		}
    		UserTable.JDBCclose();   //�ر����ݿ�����
    	}
    });
    button_Login.setBounds(88, 287, 113, 27);
    jp.add(button_Login);
    
    JButton button_register = new JButton("\u6CE8\u518C"); //ע��
    button_register.setToolTipText("ֻ��ע����ͨ�û�");
    button_register.addActionListener(new ActionListener() {
    	public void actionPerformed(ActionEvent e) {
    		if(comboBox.getSelectedIndex()==0)
			{
			try {
				dispose();
				RegisterGUI window = new RegisterGUI();
				window.frame.setVisible(true);
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			}
			else {
				try {
					JOptionPane.showMessageDialog(null, "��Ǹ����Ա���ǿ�ע�������", "��Ȩע�����Ա", JOptionPane.ERROR_MESSAGE);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
    		
    		
    	}
    });
    button_register.setBounds(274, 287, 113, 27);                   
    jp.add(button_register);
    
    JButton button_exit = new JButton("\u9000\u51FA");  //�˳�
    button_exit.setBounds(355, 413, 79, 27);
    button_exit.setMnemonic(KeyEvent.VK_ENTER);    //��ݼ�ALT+ENTER
    button_exit.setToolTipText("����ALT+�س��˳�");
    jp.add(button_exit);
    
  
    button_exit.addActionListener(new ActionListener() {
      
        @Override
        public void actionPerformed(ActionEvent e) {
            // TODO �Զ����ɵķ������
            if(e.getActionCommand().equals("�˳�")){   
             
                dispose();   //�رյ�ǰ����
            }
        }
    });

    setBounds(400, 200, 500, 500);
    setVisible(true);
}


public void setBak(){  //���ñ���ͼƬ


    ((JPanel)this.getContentPane()).setOpaque(false);
    ImageIcon img = new ImageIcon("E://background.jpg"); //����ͼƬ
    JLabel background = new JLabel(img); 
    this.getLayeredPane().add(background, new Integer(Integer.MIN_VALUE));
    background.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
}


public static void main(String[] args) {
	try {
   GUI s = new GUI();
   s.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	
	

}
	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}