package User_Interface_layer;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;

import Business_Logic_Layer.Book;
import Business_Logic_Layer.Rent;
import Business_Logic_Layer.User;
import Business_Logic_Layer.YXZP;
import Data_access_layer.UserTable;
import Data_access_layer.YXZPTable;

import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class RentConfirm {
	public String name;
    public int id;
    public int days;
	public JFrame frame;
    public  int fee;
    public  int balance;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RentConfirm window = new RentConfirm(0,0);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public RentConfirm(int x,int y) throws SQLException, ClassNotFoundException {
		id=x;
		days=y;
		name=GUI.uname;
		
		balance=GUI.balance;
		initialize();
		
	}
	public void setfee() throws SQLException, ClassNotFoundException {
		fee=YXZP.cacu_fee(id, days);
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	private void initialize() throws SQLException, ClassNotFoundException {
		setfee();
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton_yes = new JButton("\u786E\u8BA4");   //ȷ��
		btnNewButton_yes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ba;
				int new_balance = 0;
				try {
					UserTable us = new UserTable();
					us.Select();
					while(UserTable.resultSet.next()) {
						if(UserTable.resultSet.getString("uname").equals(GUI.uname)) {
							ba=UserTable.resultSet.getInt("umoney");
							new_balance=balance-fee;
						}
					}
					UserTable.JDBCclose();
				} catch (ClassNotFoundException | SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
				
				 
				if(new_balance<0) {
					BalanceBad b=new BalanceBad();
					b.frame.setVisible(true);
				}
				else {
					int root_balance = 0;
					try {int uid = 0;
						User usr=new User();
						User.ChangeUmoney(GUI.uname, new_balance);
						while(UserTable.resultSet.next()) {
							if(UserTable.resultSet.getString("uname").equals(GUI.uname))
							uid=UserTable.resultSet.getInt("uid");
							
									
						}
						
						UserTable.resultSet.beforeFirst();
						while(UserTable.resultSet.next()) {
							if(UserTable.resultSet.getString("uname").equals("root"));
							root_balance=UserTable.resultSet.getInt("umoney");
							
									
						}
						User.ChangeUmoney("root",root_balance+fee );
						Rent rent=new Rent();
						rent.Insert(uid, id, days,  fee);
						YXZP  yx=new YXZP();
						yx.ChangeStatus(id);
						Book  b1=new Book();
						b1.Change_astatus0(id);
						UserTable.JDBCclose();
						YXZPTable.Close();
						
							
						frame.dispose();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		
		btnNewButton_yes.setBounds(84, 180, 113, 27);         
		frame.getContentPane().add(btnNewButton_yes);
		
		JButton btnNewButton_no = new JButton("\u53D6\u6D88");   //ȡ��
		btnNewButton_no.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnNewButton_no.setBounds(232, 180, 113, 27);
		frame.getContentPane().add(btnNewButton_no);
		
		JLabel label = new JLabel("\u60A8\u7684\u4F59\u989D\u4E3A\uFF1A");
		label.setBounds(14, 13, 72, 18);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("\u672C\u6B21\u79DF\u501F\u5C06\u6263\u9664\uFF1A");
		label_1.setBounds(93, 101, 135, 27);
		frame.getContentPane().add(label_1);
		
		
		JLabel lblNewLabel_balance = new JLabel(String.valueOf(GUI.balance)); //���
		lblNewLabel_balance.setBounds(84, 13, 72, 18);
		frame.getContentPane().add(lblNewLabel_balance);
		
		JLabel lblNewLabel_fee = new JLabel(String.valueOf(fee));
		lblNewLabel_fee.setBounds(242, 105, 72, 18);
		frame.getContentPane().add(lblNewLabel_fee);
		
		
		JLabel label_2 = new JLabel("\u5143");
		label_2.setBounds(330, 105, 72, 18);
		frame.getContentPane().add(label_2);
	}
}
