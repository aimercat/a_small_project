package User_Interface_layer;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;

import Business_Logic_Layer.Book;
import Business_Logic_Layer.YXZP;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class BookGUI {

	JFrame frame;
	public static int id;
	public static int uid;
	public static int rid;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookGUI window = new BookGUI(0, 0, 0);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public BookGUI(int _id,int u_id,int r_id) {
		
		id=_id;
		uid=u_id;
		rid=r_id;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("\u786E\u5B9A");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					YXZP  y=new YXZP();
					y.ChangeStatus2(id);
					Book b1=new Book();
					b1.Set(uid, rid, id, 1);
					b1.Book_insert();
					frame.dispose();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(68, 172, 113, 27);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u53D6\u6D88");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnNewButton_1.setBounds(238, 172, 113, 27);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("\u662F\u5426\u8981\u9884\u8BA2\u6B64\u4E66\uFF1F");
		lblNewLabel.setFont(new Font("����", Font.BOLD | Font.ITALIC, 23));
		lblNewLabel.setBounds(98, 96, 220, 48);
		frame.getContentPane().add(lblNewLabel);
	}

}
