package User_Interface_layer;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Register_success {

	protected JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register_success window = new Register_success();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Register_success() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("\u6CE8\u518C\u6210\u529F\uFF01");
		label.setFont(new Font("����", Font.BOLD, 32));
		label.setBounds(130, 52, 215, 71);
		frame.getContentPane().add(label);
		
		JButton button = new JButton("\u786E\u5B9A");
		button.setToolTipText("�˳������ص�¼����");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getActionCommand().equals("ȷ��")){ 
					GUI   l2=new GUI();
	                frame.dispose();                        //�ص���¼����   �رյ�ǰ����
	                
	            }
			}
		});
		button.setBounds(151, 137, 92, 27);
		frame.getContentPane().add(button);
	}

}
