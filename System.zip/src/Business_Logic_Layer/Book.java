package Business_Logic_Layer;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import Data_access_layer.BookTable;
import Data_access_layer.UserTable;
import Data_access_layer.YXZPTable;

public class Book {
	public int aid;
	public int uid;
	public int rid;         //��Ӧ���ѱ�������Ʒ������¼������
	public int id;          //��Ʒ��
	public int status;  //Ԥ��״̬     ��״̬�������û�����Ԥ������Ʒ
	public static int count;
	
	public static void Change_astatus2(int rid) throws SQLException{
		String sql="update Ԥ����  set astatus=? where rid="+String.valueOf(rid);
		
	    PreparedStatement pre;
	
		pre = BookTable.con.prepareStatement(sql);
		pre.setInt(1, 2);
		int i=pre.executeUpdate();
	    pre.close();
	}
	public static void Change_astatus0(int id) throws SQLException{
		String sql="update Ԥ����  set astatus=? where id="+String.valueOf(id);
		
	    PreparedStatement pre;
	
		pre = BookTable.con.prepareStatement(sql);
		pre.setInt(1, 0);
		int i=pre.executeUpdate();
	    pre.close();
	}
	public static void getcount() throws SQLException {//��ȡ����
		   try {
		  BookTable.resultSet.beforeFirst();
		   BookTable.resultSet.last();
		   count=BookTable.resultSet.getRow();
		   }catch(SQLException e) {
			   e.printStackTrace();
		   }
		   finally {
			   BookTable.resultSet.beforeFirst();
		   }
	   }
	 public Book() {  //��������
		   try {
			   
		   
		   BookTable  b=new BookTable();
		   
		   BookTable.Select();
		   getcount();   //��ȡ��¼��
		   }
		   catch(Exception e) {
			   e.printStackTrace();
		   }
	   }
	 public void Set(int u_id,int r_id,int _id,int i) {
		 aid=count+1;
		 uid=u_id;
		 rid=r_id;
		 id=_id;
		 status=i;
	 }
	 public void Book_insert() throws SQLException {  //�������ݿ�
			String ins="insert into Ԥ����(aid,uid,rid,id,astatus)  values (?,?,?,?,?)";
			try{
				status=1;
				PreparedStatement pre = UserTable.con.prepareStatement(ins);//ʵ����
	            pre.setInt(1, aid);
	            pre.setInt(2, uid);
	            pre.setInt(3, rid);
	            pre.setInt(4, id);
	            pre.setInt(5, status);
	           
	            pre.executeUpdate();     //ִ�в���
	           
	            pre.close();  //�ر�
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
		}
	 
}
