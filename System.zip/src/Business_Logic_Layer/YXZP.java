package Business_Logic_Layer;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import Data_access_layer.Type_value;
import Data_access_layer.UserTable;
import Data_access_layer.YXZPTable;

public class YXZP {
public  String  name;	
public  String sname;
public  String scountry;
public static final String Select="select * from ������Ʒ��";
private String sql=null;
public  final String stype1=" and type=1";
public  final String stype2=" and type=2";
public  final String stype3=" and type=3";	
public  final String stype4=" and type=4";
public static final String SelectW="select * from ������Ʒ�� where rstatus>=0";                       //����״̬
public static final String yrent="select * from ������Ʒ�� where rstatus=0";              //δ���
public static final String ybook="select * from ������Ʒ�� where rstatus=1";               //�Ѿ������Ԥ��
public static final String nbook="select * from ������Ʒ�� where rstatus=2";               //�Ѿ�������ѱ�Ԥ��,������Ԥ��
public void setsql() {
	sql=Select;
}
public void setname(String n) {
	if(n.isBlank()) {
		name="";
		sname="";
	}
		
	else {
	name=n;
	sname=" and name like "+"\'%"+n+"%\'";
	
	}
}
public void setcountry(String country) {
	if(country.isBlank()) {
		scountry="";
	}
	else {
		scountry=" and country like "+"\'%"+country+"%\'";
	}
}
public static int cacu_fee(int id,int days) throws SQLException, ClassNotFoundException {
	int price=id_s_p(id);
	int fee=price*days;
	return fee;//�������
	
	
}
public YXZP() {   //���ӽ���
	try {
		YXZPTable.init();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
public void SQL(int x,int y) {  //���ɶ�Ӧ��sql���
	if(x==0) {
		if(y==1) 
			sql=SelectW+stype1+scountry+sname;
			
		else if(y==2) 
			sql=SelectW+stype2+scountry+sname;
		else if(y==3)
		    sql=SelectW+stype3+scountry+sname;
		else if(y==4)
			sql=SelectW+stype4+scountry+sname;
		else if(y==0)
			sql=SelectW+scountry+sname;
		
	}
	else if(x==1) {
		if(y==1) 
			sql=yrent+stype1+scountry+sname;
			
		else if(y==2) 
			sql=yrent+stype2+scountry+sname;
		else if(y==3)
		    sql=yrent+stype3+scountry+sname;
		else if(y==4)
			sql=yrent+stype4+scountry+sname;
		else if(y==0)
			sql=yrent+scountry+sname;
	}
	else if(x==2) {
		if(y==1) 
			sql=ybook+stype1+scountry+sname;
			
		else if(y==2) 
			sql=ybook+stype2+scountry+sname;
		else if(y==3)
		    sql=ybook+stype3+scountry+sname;
		else if(y==4)
			sql=ybook+stype4+scountry+sname;
		else if(y==0) {
			sql=ybook+scountry+sname;
		}
	}
}
public static int id_s_p(int sid) throws SQLException, ClassNotFoundException {   //��id����price
	YXZPTable.Select(Select);
	int price = 0;
		while(YXZPTable.resultSet.next()) {
			if(YXZPTable.resultSet.getInt("id")==sid) {
				Type_value type=new Type_value();
				Type_value.Select();
				Type_value.se_value(YXZPTable.resultSet.getString("type"));
			price=Type_value.value;
			
			
			}
			
			
		}
		return price;
		
		
		
			
}
public  void Select() {
	YXZPTable.Select(sql);
}
public static void ChangeStatus(int _id) throws SQLException {
	
	String sql="update ������Ʒ��  set rstatus=? where id="+String.valueOf(_id);
	
	PreparedStatement pre = YXZPTable.con.prepareStatement(sql);
	pre.setInt(1, 1);
	int i=pre.executeUpdate();
    pre.close();
	
}
public static void ChangeStatus0(int id) throws SQLException {
String sql="update ������Ʒ��  set rstatus=? where id="+String.valueOf(id);
	
	    PreparedStatement pre;
	
		pre = YXZPTable.con.prepareStatement(sql);
		pre.setInt(1, 0);
		int i=pre.executeUpdate();
	    pre.close();
	
	
}
public static void ChangeStatus2(int id) throws SQLException {
String sql="update ������Ʒ��  set rstatus=? where id="+String.valueOf(id);
	
	    PreparedStatement pre;
	
		pre = YXZPTable.con.prepareStatement(sql);
		pre.setInt(1, 2);
		int i=pre.executeUpdate();
	    pre.close();
	
	
}
}
