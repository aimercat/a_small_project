package Business_Logic_Layer;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import Data_access_layer.UserTable;
import User_Interface_layer.GUI;
import User_Interface_layer.LoginBad;
import User_Interface_layer.RentGUI;
import User_Interface_layer.RootGUI;

public class User {
   public static int index; //��ʶ��ǰ��
   
   public String  uname;
   public static int    u_id;    //�û�id
   public static int uid;   //��̬   ע���uid
   public static int count;  //��¼�û�����
   public String   Login_password;  //��ȡ����
   public String  upassword;
   public String  uaddress;
   public String  email;
   public String  phone;
   private String root="0";
   private int   umoney=200;  //ע���ʼ�ʽ�Ϊ200

   public static void getcount() throws SQLException {//��ȡ����
	   try {
	   UserTable.resultSet.beforeFirst();
	   UserTable.resultSet.last();
	   count=UserTable.resultSet.getRow();
	   }catch(SQLException e) {
		   e.printStackTrace();
	   }
	   finally {
		   UserTable.resultSet.beforeFirst();
	   }
   }
   public int getmoney() {
	   return umoney;
	   
   }
   public User() {  //��������
	   try {
		   
	   
	   UserTable  us=new UserTable();
	   
	   UserTable.Select();
	   getcount();   //��ȡ��¼��
	   }
	   catch(Exception e) {
		   e.printStackTrace();
	   }
   }
   
   public boolean Is_name(String s) throws SQLException{   //�ж����޸��û���
	   
	   int k=0,i=0;
	   u_id=1;
	   try {
		   
	   while(UserTable.resultSet.next())
	   {   
		   
		   if(UserTable.resultSet.getString("uname").equals(s)) {
			   Login_password=UserTable.resultSet.getString("password");  //��ȡ���û����µ�����
			   root=UserTable.resultSet.getString("root");   //��ȡȨ��
			   umoney=UserTable.resultSet.getInt("umoney");
			   u_id=UserTable.resultSet.getInt("uid");
			   k++;
			   break;
		   }
		   
		  
	   }
	   		}catch(SQLException e) {
	   			e.printStackTrace();
	   		}
	  
	   UserTable.resultSet.beforeFirst();  //��귵�ؿ�ʼ
	   if(k!=0)
	   return true;   //�û����ظ�|�û�����֤�ɹ�
	   else
	   return false;   //���ظ�|�޴��û���
   }
   public  boolean Login(String name,String password) throws SQLException {   //��¼
	   
		   
	   
	   if(Is_name(name)) {
		   if(Login_password.equals(password)&&!root.equals("root")) {
			   RentGUI  window=new RentGUI();   //��¼�ɹ��������ҳ��
			   window.frame.setVisible(true);
			   
			   return false;
		   }
		   else if(Login_password.equals(password)&&root.equals("root")){
			   RentGUI  window=new RentGUI();   //��¼�ɹ��������ҳ��
			   window.frame.setVisible(true);
			   
			   RootGUI rootwindow=new RootGUI();
			   rootwindow.frame.setVisible(true);
			   return true;    //ֻ�й���ԱΪ��
		   }
		   else {
			   
			   LoginBad window=new LoginBad();
			   window.frame.setVisible(true);
			  
			   return false;
		   }
	   }
	   else {
		   LoginBad window=new LoginBad();
		   window.frame.setVisible(true);
		   return false;
	   }
	   
	   
	
	   
   }

	public  void  SetUsr(String n,String p,String a,String e,String ph) throws SQLException {    //����ע��ʱ����
		
		uname=n;         
		uid=count+1;      //uidΪ֮ǰ��¼����һ
		upassword=p;
		uaddress=a;
		email=e;
		phone=p;
	
	}
	public static void ChangeUmoney(String name,int new_balance ) throws SQLException {
		
		String sql="update �û���Ϣ��  set umoney=? where uname="+"\'"+name+"\'";
		
		PreparedStatement pre = UserTable.con.prepareStatement(sql);
		pre.setInt(1, new_balance);
	    pre.executeUpdate();
        pre.close();
		
	}
	public void Register_insert() throws SQLException {  //�������ݿ�
		String ins="insert into �û���Ϣ��(uid,umoney,uname,password,address,email,phone,root)  values (?,?,?,?,?,?,?,?)";
		try{
			PreparedStatement pre = UserTable.con.prepareStatement(ins);//ʵ����
            pre.setInt(1, uid);
            pre.setInt(2, umoney);
            pre.setString(3, uname);
            pre.setString(4, upassword);
            pre.setString(5, uaddress);
            pre.setString(6, email);
            pre.setString(7, phone);
            pre.setString(8, "0");
            pre.executeUpdate();     //ִ�в���
           
            pre.close();  //�ر�
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}

}