package Data_access_layer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RentTable {   //���������������ݿ��ȡԤ�����е���Ϣ        
    public  static Object[][] Data;
	public static Connection con=null;
	public static Statement stmt=null;
	public static ResultSet resultSet=null;
	public static final String forname="com.mysql.cj.jdbc.Driver";
	public static final String path="jdbc:mysql://localhost:3306/yinxiang?useSSL=true&serverTimezone=UTC";
	public static final String root="root";
	public static final String password="123456";
	public static final String SelectRent="select * from ����";
	public static final String Insert="";
	static int count;
	public static int row;
	public static void Select_uid(int uid) {
		String sql="select * from ����  where uid="+String.valueOf(uid)+" and flag=1";
		try{
		    stmt=con.createStatement();
			resultSet=stmt.executeQuery(sql);   //��ѯ����
			 
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	public static void Select_id(int id) {
		String sql="select * from ����  where id="+String.valueOf(id);
		try{
		    stmt=con.createStatement();
			resultSet=stmt.executeQuery(sql);   //��ѯ����
			 
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	public static void setrow() throws SQLException {
		   try {
			   resultSet.beforeFirst();
			   resultSet.last();
			   row=resultSet.getRow();
			   }catch(SQLException e) {
				   e.printStackTrace();
			   }
			   finally {
				   resultSet.beforeFirst();
			   }
	}
	public  RentTable() throws ClassNotFoundException  {
	Init();
		
	}
	public static void Init() throws ClassNotFoundException {
		try {
			  //����һ��MYSQL���Ӷ���
	       Class.forName(forname); //MYSQL����
	        con = DriverManager.getConnection(path, root, password); //���ӱ���MYSQL

	        
		}catch(SQLException e) {
			e.printStackTrace();
			System.out.println("����ʧ�ܣ�");
		}
	}
	public static void  Select() {
		try{
			    stmt=con.createStatement();
				resultSet=stmt.executeQuery(SelectRent);   //��ѯ����
				 
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
			
		}
	 public static Object[][] queryData() throws SQLException {             //���Ҫ�ڱ�����ʾ������
	        setrow();
	        
	        Object[][] data=new Object[row][4];
          int i=0;
          try {
	        while(resultSet.next()) {
	        	
	            
	                data[i][0]=resultSet.getObject("rid");
	                data[i][1]=resultSet.getObject("id");
	                data[i][2]=resultSet.getObject("flag");
                     i++;
	            }
	        }catch(SQLException e) {
	        	e.printStackTrace();
	        }
	        Data=data;
	        return (Object[][]) data;
	    }
	public  static void JDBCclose(){     //�ر�����
		try {
			resultSet.close();
			stmt.close();
			con.close();
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
}
