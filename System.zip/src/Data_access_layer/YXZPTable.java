package Data_access_layer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class YXZPTable {
	public static int row=0;
	public static  final int col=9;
	public static Connection con=null;
	public static Statement stmt=null;
	public static ResultSet resultSet=null;
	public static final String forname="com.mysql.cj.jdbc.Driver";
	public static final String path="jdbc:mysql://localhost:3306/yinxiang?useSSL=true&serverTimezone=UTC";
	public static final String root="root";
	public static final String password="123456";
	public static String Select;
	public static final String SelectYX="select * from ������Ʒ��";
	public static final String SelectW="select * from ������Ʒ�� where ";
    public static Object[][]  Data;
	public static final String Insert="";
	public static void setrow() throws SQLException {
		   try {
			   resultSet.beforeFirst();
			   resultSet.last();
			   row=resultSet.getRow();
			   }catch(SQLException e) {
				   e.printStackTrace();
			   }
			   finally {
				   resultSet.beforeFirst();
			   }
	}
	public void setSelect(String name) {
		Select=SelectW+"name="+name;
	}
	public YXZPTable() throws ClassNotFoundException {
	init();
	}
	public static void init() throws ClassNotFoundException {
		try {
			  //����һ��MYSQL���Ӷ���
	       Class.forName(forname); //MYSQL����
	        con = DriverManager.getConnection(path, root, password); //���ӱ���MYSQL

	        
		}catch(SQLException e) {
			e.printStackTrace();
			System.out.println("����ʧ�ܣ�");
		}
	}
	public static void  Select(String sql) {
		try{
			stmt=con.createStatement();
			resultSet=stmt.executeQuery(sql);			     
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
			
		}
	
	 public static Object[][] queryData() throws SQLException {             //���Ҫ�ڱ�����ʾ������
	        setrow();
	       
	        Object[][] data=new Object[row][col];
             int i=0;
             try {
	        while(resultSet.next()) {
	        	
	            
	                data[i][0]=resultSet.getObject("id");
	                data[i][1]=resultSet.getObject("type");
	                data[i][2]=resultSet.getObject("name");
	                data[i][3]=resultSet.getObject("editor");
	                data[i][4]=resultSet.getObject("performer");
	                data[i][5]=resultSet.getObject("country");
	                data[i][6]=resultSet.getObject("showdate");
	                data[i][7]=resultSet.getObject("info");
	                data[i][8]=resultSet.getObject("rstatus");
	                i++;
	            }
	        }catch(SQLException e) {
	        	e.printStackTrace();
	        }
	        Data=data;
	        return (Object[][]) data;
	    }
		public  static void JDBCclose(){     //�ر�����
			try {
				resultSet.close();
				stmt.close();
				con.close();
			
			}catch(Exception e) {
				e.printStackTrace();
			}
			
			
		}
		public static void Close()  {
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
}
