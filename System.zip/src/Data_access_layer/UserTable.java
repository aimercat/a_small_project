package Data_access_layer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class UserTable {
	public static Connection con=null;
	public static Statement stmt=null;
	public static ResultSet resultSet=null;
	public static final String forname="com.mysql.cj.jdbc.Driver";
	public static final String path="jdbc:mysql://localhost:3306/yinxiang?useSSL=true&serverTimezone=UTC";
	public static final String root="root";
	public static final String password="123456";
	public static final String SelectUser="select * from �û���Ϣ��";
	public static final String Insert="";
	public static Object[][]  Data;
	public static int row=0;
	public static void setrow() throws SQLException {
		   try {
			   resultSet.beforeFirst();
			   resultSet.last();
			   row=resultSet.getRow();
			   }catch(SQLException e) {
				   e.printStackTrace();
			   }
			   finally {
				   resultSet.beforeFirst();
			   }
	}
public  UserTable() throws SQLException, ClassNotFoundException {   //��������

	try {
		  //����һ��MYSQL���Ӷ���
       Class.forName(forname); //MYSQL����
        con = DriverManager.getConnection(path, root, password); //���ӱ���MYSQL

        
	}catch(SQLException e) {
		e.printStackTrace();
		System.out.println("����ʧ�ܣ�");
	}
	
	
}
public static Object[][] queryData() throws SQLException {             //���Ҫ�ڱ�����ʾ������
    setrow();
   
    Object[][] data=new Object[row][7];
     int i=0;
     try {
    while(resultSet.next()) {
    	
        
            data[i][0]=resultSet.getObject("uid");
            data[i][1]=resultSet.getObject("umoney");
            data[i][2]=resultSet.getObject("uname");
            data[i][3]=resultSet.getObject("password");
            data[i][4]=resultSet.getObject("address");
            data[i][5]=resultSet.getObject("email");
            data[i][6]=resultSet.getObject("phone");

            i++;
        }
    }catch(SQLException e) {
    	e.printStackTrace();
    }
    Data=data;
    return (Object[][]) data;
}
public static void  Select() {
try{
	    stmt=con.createStatement();
		resultSet=stmt.executeQuery(SelectUser);   //��ѯ�û���Ϣ��
		 
	}
	catch(SQLException e) {
		e.printStackTrace();
	}
	
}
public  static void JDBCclose(){     //�ر�����
	try {
		resultSet.close();
		stmt.close();
		con.close();
	
	}catch(Exception e) {
		e.printStackTrace();
	}
	
	
}


	}




