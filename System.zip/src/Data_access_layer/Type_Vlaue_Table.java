package Data_access_layer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Type_Vlaue_Table {
	public static Connection con=null;
	public static Statement stmt=null;
	public static ResultSet resultSet=null;
	public static final String forname="com.mysql.cj.jdbc.Driver";
	public static final String path="jdbc:mysql://localhost:3306/yinxiang?useSSL=true&serverTimezone=UTC";
	public static final String root="root";
	public static final String password="123456";
	public static final String SelectUser="select * from �����";
	public static final String Insert="";
	public Type_Vlaue_Table() throws ClassNotFoundException {
		// TODO Auto-generated constructor stub
	
		try {
			  //����һ��MYSQL���Ӷ���
	       Class.forName(forname); //MYSQL����
	        con = DriverManager.getConnection(path, root, password); //���ӱ���MYSQL

	        
		}catch(SQLException e) {
			e.printStackTrace();
			System.out.println("����ʧ�ܣ�");
		}
	}
	public static void  Select() {
		try{
			    stmt=con.createStatement();
				resultSet=stmt.executeQuery(SelectUser);   //��ѯԤ����
				 
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
			
		}
		public  static void JDBCclose(){     //�ر�����
			try {
				resultSet.close();
				stmt.close();
				con.close();
			
			}catch(Exception e) {
				e.printStackTrace();
			}
			
			
		}
}
