package Data_access_layer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BookTable {
	public static Connection con=null;
	public static Statement stmt=null;
	public static ResultSet resultSet=null;
	public static final String forname="com.mysql.cj.jdbc.Driver";
	public static final String path="jdbc:mysql://localhost:3306/yinxiang?useSSL=true&serverTimezone=UTC";
	public static final String root="root";
	public static final String password="123456";
	public static final String SelectUser="select * from Ԥ����";
	public static final String Insert="";
	public static Object[][] Data;
	public static int row;
	public static void setrow() throws SQLException {
		   try {
			   resultSet.beforeFirst();
			   resultSet.last();
			   row=resultSet.getRow();
			   }catch(SQLException e) {
				   e.printStackTrace();
			   }
			   finally {
				   resultSet.beforeFirst();
			   }
	}
	public static void  root_select() {
		String sql="select * from Ԥ����  where astatus=2";
		try{
		    stmt=con.createStatement();
			resultSet=stmt.executeQuery(sql);   //��ѯԤ����
			 
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	 public static Object[][] queryData() throws SQLException {             //���Ҫ�ڱ�����ʾ������
	        setrow();
	        
	        Object[][] data=new Object[row][4];
       int i=0;
       try {
	        while(resultSet.next()) {
	        	
	            
	                data[i][0]=resultSet.getObject("aid");
	                data[i][1]=resultSet.getObject("uid");
	                data[i][2]=resultSet.getObject("id");
	                data[i][3]=resultSet.getObject("astatus");
                  i++;
	            }
	        }catch(SQLException e) {
	        	e.printStackTrace();
	        }
	        Data=data;
	        return (Object[][]) data;
	    }
	public  BookTable() throws ClassNotFoundException {
		try {
			  //����һ��MYSQL���Ӷ���
	       Class.forName(forname); //MYSQL����
	        con = DriverManager.getConnection(path, root, password); //���ӱ���MYSQL

	        
		}catch(SQLException e) {
			e.printStackTrace();
			System.out.println("����ʧ�ܣ�");
		}
	}
	public static void  Select() {
		try{
			    stmt=con.createStatement();
				resultSet=stmt.executeQuery(SelectUser);   //��ѯԤ����
				 
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
			
		}
		public  static void JDBCclose(){     //�ر�����
			try {
				resultSet.close();
				stmt.close();
				con.close();
			
			}catch(Exception e) {
				e.printStackTrace();
			}
			
			
		}
	
}
