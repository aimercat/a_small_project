package Data_access_layer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Type_value {
	public static int value;
	public static Connection con=null;
	public static Statement stmt=null;
	public static ResultSet resultSet=null;
	public static final String forname="com.mysql.cj.jdbc.Driver";
	public static final String path="jdbc:mysql://localhost:3306/yinxiang?useSSL=true&serverTimezone=UTC";
	public static final String root="root";
	public static final String password="123456";
	public static final String SelectUser="select * from �����";
	public static final String Insert="";
public  Type_value() throws SQLException, ClassNotFoundException {   //��������

	try {
		  //����һ��MYSQL���Ӷ���
       Class.forName(forname); //MYSQL����
        con = DriverManager.getConnection(path, root, password); //���ӱ���MYSQL

        
	}catch(SQLException e) {
		e.printStackTrace();
		System.out.println("����ʧ�ܣ�");
	}
	
	
}
public static void  Select() {
try{
	    stmt=con.createStatement();
		resultSet=stmt.executeQuery(SelectUser);   //��ѯ�����
		 
	}
	catch(SQLException e) {
		e.printStackTrace();
	}
	
}
public  static void  se_value(String i) throws SQLException {  //�ҵ���Ӧ����ļ۸�
	while(resultSet.next()) {
		if(resultSet.getString("type").equals(i))
			 value=resultSet.getInt("price");
		
	}
	
}
public  int getvalue() {
	return value;
}
public  static void JDBCclose(){     //�ر�����
	try {
		resultSet.close();
		stmt.close();
		con.close();
	
	}catch(Exception e) {
		e.printStackTrace();
	}
	
	
}

}
